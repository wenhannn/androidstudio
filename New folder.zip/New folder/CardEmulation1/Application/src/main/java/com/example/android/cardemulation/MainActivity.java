/*
* Copyright 2013 The Android Open Source Project
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/


package com.example.android.cardemulation;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.android.common.activities.SampleActivityBase;
public class MainActivity extends SampleActivityBase {

    private boolean mLogShown;
    public static final String TAG = "MainActivity";

    EditText cardnumber;
    TextView foodorders;
    Button buttonorder,addsub;
    private static final int REQUEST_CODE = 10;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cardnumber = (EditText) findViewById(R.id.card_account_field);
        cardnumber.setText(AccountStorage.GetAccount(getBaseContext()));
        cardnumber.addTextChangedListener(new AccountUpdater());
        foodorders = (TextView) findViewById(R.id.foodordershow);
        buttonorder = (Button) findViewById(R.id.buttonorder);
        addsub = (Button) findViewById(R.id.buttonregister);

        addsub.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),register.class);
                startActivity(intent);
            }
        });



        buttonorder.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String strcardnumber = cardnumber.getText().toString();
                Intent intent = new Intent(getApplicationContext(), activityresult1.class);
                intent.putExtra("Card Number",strcardnumber);
                startActivityForResult(intent, REQUEST_CODE);
            }
        });



    }

    private class AccountUpdater implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            // Not implemented.
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // Not implemented.
        }

        @Override
        public void afterTextChanged(Editable s) {
            String account = s.toString();
            AccountStorage.SetAccount(getBaseContext(), account);
        }
    }
}




