package com.example.android.cardemulation;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class register2 extends Activity {

    Button confirm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register2);


        Bundle extras = getIntent().getExtras();
        String strName = extras.getString("Name:");
        String strNric = extras.getString("NRIC:");
        String strAdress = extras.getString("Adress:");
        String strMobile = extras.getString("Mobile:");
        String strEmail = extras.getString("Email:");

        TextView registertext = (TextView) findViewById(R.id.registertext);
        registertext.setText("Please confirm your , \nName: " + strName + "\nNRIC: " + strNric + "\nAddress: "
                + strAdress + "\nMobile Number : " + strMobile + "\nEmail: " + strEmail + "" + "\nIf wrong please " +
                "return to the previous menu and re-enter the correct informations! \n\nElse please press submit!  ");
    }

    public void confirm (View view){
        Context context = getApplicationContext();
        CharSequence text =" Thank you for submitting , you may now start to order!";
        int duration= Toast.LENGTH_SHORT;

        Toast toast=Toast.makeText(context,text,duration);

        toast.show();
    }
}