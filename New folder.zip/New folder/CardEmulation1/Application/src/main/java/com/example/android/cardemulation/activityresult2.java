package com.example.android.cardemulation;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class activityresult2 extends Activity {

    static public String txtOrder ="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activityresult2);

        Bundle bundle = getIntent().getExtras();
        String strfnq = bundle.getString("Noodle quantity");
        String strfrq = bundle.getString("Rice quantity");
        String strfsq = bundle.getString("Fish quantity");
        String stricq = bundle.getString("Iced tea");
        Integer strsum = bundle.getInt("sum");

        boolean addNingc = bundle.getBoolean("ANI");
        boolean addRingc = bundle.getBoolean("ARI");
        boolean addFingc = bundle.getBoolean("AFI");
        boolean addTingc = bundle.getBoolean("AIT");
        boolean addmoneyc = bundle.getBoolean("AMY");

        Intent mIntent = getIntent();

        int sum = mIntent.getIntExtra("sum",strsum);
        TextView costtext = (TextView)findViewById(R.id.costtext);
        costtext.setText(String.valueOf(sum));

        TextView foodorders = (TextView) findViewById(R.id.foodordershow);
        foodorders.setText(getIntent().getExtras().getString("Quantity"));

        String addNdlThing = "";
        if (addNingc) { 
            addNdlThing = " with addition of ingredients";
        }

        String addRlThing = "";
        if (addRingc) {
            addRlThing = " with addition of ingredients";
        }

        String addSlThing = "";
        if ( addFingc) {
            addSlThing = " with addition of ingredients";
        }

         String addTeac = "";
        if ( addTingc ) {
            addTeac = " with addition of ingredients";
        }

        foodorders = (TextView) findViewById(R.id.foodordershow);
        if(strfnq.equals("") && strfrq.equals("") && strfsq.equals("")&& stricq.equals("")){
            txtOrder = "Sorry, You've not ordered any thing , please return to previous menu to order";
        }else if (!strfnq.equals("") && !strfrq.equals("") && !strfsq.equals("")&& stricq.equals("")) {
            txtOrder = "Thank you , You've ordered\n" + strfnq + " fried noodle" + addNdlThing +" and\n"+ strfrq
                    + " fried rice" + addRlThing +" and\n" + strfsq + " Steam fish " + addSlThing + "and\n" + stricq + " Steam fish " + addTeac;
        } else {
            txtOrder = "Thank you , You've ordered\n";
            if(!strfnq.equals("")){
                txtOrder = txtOrder + strfnq + " fried noodle" + addNdlThing;
            }
            if(!strfrq.equals("")){
                txtOrder = txtOrder + strfrq + " fried rice" + addRlThing;
            }
            if(!strfsq.equals("")){
                txtOrder = txtOrder + strfsq + " Steam fish" + addSlThing;
            }
            if(!stricq.equals("")){
                txtOrder = txtOrder + stricq + " Iced Tea"+ addTeac;
            }
        }
        foodorders.setText(txtOrder);
    }
}



