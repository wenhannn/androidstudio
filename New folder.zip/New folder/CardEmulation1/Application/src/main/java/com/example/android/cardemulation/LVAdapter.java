package com.example.android.cardemulation;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class LVAdapter extends BaseAdapter {

    private Context context;
    LayoutInflater inflater;
    private ArrayList<DataInfo> objectList;

    private class ViewHolder {
        TextView title,description,cost;
        CheckBox add, addIn;
        ImageView image;
        EditText quantity;
    }
    public LVAdapter(Context context, ArrayList<DataInfo> objectList) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.objectList = objectList;
    }
    public int getCount() {
        return objectList.size();
    }

    public DataInfo getItem(int position) {
        return objectList.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
         ViewHolder holder = null;
        if(convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.item_menu, null);
            holder.title = (TextView) convertView.findViewById(R.id.tv_title);
            holder.add = (CheckBox) convertView.findViewById(R.id.addnc);
            holder.addIn = (CheckBox) convertView.findViewById(R.id.addningc);
            holder.image = (ImageView)convertView.findViewById(R.id.fridenoodle);
            holder.quantity = (EditText)convertView.findViewById(R.id.fnq);
            holder.quantity.addTextChangedListener(new MyTextWatcher(convertView));
            holder.description = (TextView) convertView.findViewById(R.id.description);
            holder.cost = (TextView) convertView.findViewById(R.id.cost);
            convertView.setTag(holder);

            holder.addIn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    CheckBox cb = (CheckBox) v;
                    DataInfo object = (DataInfo) cb.getTag();
                    object.setAddInisCheck(cb.isChecked());

                }
            });
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        DataInfo object = objectList.get(position);
        holder.quantity.setText(object.getQuantity());
        holder.description.setText(object.getDescription());
        holder.cost.setText(object.getCost());
        holder.title.setText(object.getName());
        holder.addIn.setChecked(object.isAddInisCheck());
        holder.image.setImageResource(object.getImage());
        holder.addIn.setTag(object);
        holder.quantity.setTag(object);
        return convertView;
    }

    private class MyTextWatcher implements TextWatcher {

        private View view;

        private MyTextWatcher(View view) {
            this.view = view;
        }

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
            EditText qtyView = (EditText) view.findViewById(R.id.fnq);
            DataInfo object = (DataInfo) qtyView.getTag();
        }

        public void afterTextChanged(Editable s) {

        }
    };
}
