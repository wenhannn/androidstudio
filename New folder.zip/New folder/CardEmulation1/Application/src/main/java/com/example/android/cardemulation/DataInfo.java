package com.example.android.cardemulation;

/**
 * Created by Gene on 2016/3/29.
 */
public class DataInfo {
    String pID;
    String name;
    String description;
    int image;
    String cost;
    String quantity ="";
    boolean addInisCheck = false;

    public DataInfo(String name, int image, String  description, String cost) {
        this.name = name;
        this.image = image;
        this.description = description;
        this.cost = cost;
    }

    public DataInfo(String pID, String name, int image, String  description, String cost) {
        this.pID = pID;
        this.name = name;
        this.image = image;
        this.description = description;
        this.cost = cost;
    }

    public String getpID() {
        return pID;
    }

    public void setpID(String pID) {
        this.pID = pID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public boolean isAddInisCheck() {
        return addInisCheck;
    }

    public void setAddInisCheck(boolean addInisCheck) {
        this.addInisCheck = addInisCheck;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String  getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String  getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

}