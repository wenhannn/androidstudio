package com.example.android.cardemulation;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class register extends Activity {

    EditText nametext, nrictext, mobiletext,emailtext,addresstext;
    Button addsub;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        nametext = (EditText) findViewById(R.id.nametext);
        nrictext = (EditText) findViewById(R.id.nrictext);
        addresstext = (EditText) findViewById(R.id.addresstext);
        mobiletext = (EditText) findViewById(R.id.mobiletext);
        emailtext = (EditText) findViewById(R.id.emailtext);
        addsub = (Button) findViewById(R.id.addsub);


        addsub.setOnClickListener(new View.OnClickListener() {
           public void onClick(View v) {
               String strName = nametext.getText().toString();
               String strNric = nrictext.getText().toString();
               String strAdress = addresstext.getText().toString();
               String strMobile = mobiletext.getText().toString();
               String strEmail = emailtext.getText().toString();
               Intent intent = new Intent(getApplicationContext(),register2.class);
               intent.putExtra("Name:",strName);
               intent.putExtra("NRIC:",strNric);
               intent.putExtra("Adress:",strAdress);
               intent.putExtra("Mobile:",strMobile);
               intent.putExtra("Email:",strEmail);
               startActivity(intent);
           }
        });
    }
}

