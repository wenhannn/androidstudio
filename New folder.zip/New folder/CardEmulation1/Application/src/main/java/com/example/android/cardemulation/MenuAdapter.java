package com.example.android.cardemulation;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by 141575U on 29/3/2016.
 */
public class MenuAdapter extends BaseAdapter {

    private LayoutInflater mInflater;
    private Context context;
    private ArrayList<DataInfo> dataList = new ArrayList<DataInfo>();

    public MenuAdapter(Context context) {
        this.context = context;
        mInflater = (LayoutInflater) context.getSystemService
                (Context.LAYOUT_INFLATER_SERVICE);
    }

    public void addData(String pID, String name, int image, String description, String cost) {
        addData(new DataInfo(pID, name, image, description,cost ));
    }

    private void addData(DataInfo dataInfo) {
        dataList.add(dataInfo);
        notifyDataSetChanged();
    }

    public String[] getQuantity(){
        String[] a = new String[getCount()];
        for(int i = 0; i<getCount(); i++){
            a[i] = getItem(i).getQuantity();
        }
        return a;
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public DataInfo getItem(int position) {
        return dataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    public void clear() {
        dataList.clear();
    }

    class ViewHolder {
        TextView title,description,cost;
        CheckBox add, addIn;
        ImageView image;
        EditText quantity;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.item_menu, null);
            holder.title = (TextView) convertView.findViewById(R.id.tv_title);
            holder.add = (CheckBox) convertView.findViewById(R.id.addnc);
            holder.addIn = (CheckBox) convertView.findViewById(R.id.addningc);
            holder.image = (ImageView)convertView.findViewById(R.id.fridenoodle);
            holder.quantity = (EditText)convertView.findViewById(R.id.fnq);
            holder.description = (TextView) convertView.findViewById(R.id.description);
            holder.cost = (TextView) convertView.findViewById(R.id.cost);

            convertView.setTag(holder);

            holder.quantity.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    getItem(position).setQuantity(holder.quantity.getText().toString());
                }

                @Override
                public void afterTextChanged(Editable s) {

                }
            });
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.quantity.setText(getItem(position).getQuantity());
        holder.title.setText(getItem(position).getName());
        holder.description.setText(getItem(position).getDescription());
        holder.cost.setText(getItem(position).getCost());
        holder.image.setImageResource(getItem(position).getImage());
        holder.cost.setText(getItem(position).getCost());
        holder.addIn.setChecked(getItem(position).isAddInisCheck());
        holder.addIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getItem(position).setAddInisCheck(holder.addIn.isChecked());
            }
        });



        return convertView;
    }
}