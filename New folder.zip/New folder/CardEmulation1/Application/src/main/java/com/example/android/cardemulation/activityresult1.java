package com.example.android.cardemulation;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class activityresult1 extends Activity {

    ArrayList<DataInfo> itemList, selectedList;

    Button buttonorder;
    TextView textviewcard;
    private static final int REQUEST_CODE = 10;
    int[] image ={R.drawable.friednoodle, R.drawable.friedrice, R.drawable.steamfish,R.drawable.tehice};
    String[] item = {"Fried Noodle", "Fried Rice", "Steam Fish","Iced Tea"};
    String[] description = {"Classic Chinese stir fried noodle with prawn and Pork",
            "Special sauce Fried Rice using indian rice", "HongKong Style Steamed Fish ","HongKong classical iced tea"};
    String[] cost={"6","5","25","2"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activityresult1);

        Bundle extras = getIntent().getExtras();
        String strcardnumber = extras.getString("Card Number");
        textviewcard = (TextView) findViewById(R.id.textviewcard);
        textviewcard.setText("Welcome, " + strcardnumber + " !" + "\nPlease select the food you want ! : ");

        itemList = new ArrayList<DataInfo>();
        itemList.add(new DataInfo(item[0], image[0], description[0], cost[0]));
        itemList.add(new DataInfo(item[1], image[1], description[1], cost[1]));
        itemList.add(new DataInfo(item[2], image[2], description[2], cost[2]));
        itemList.add(new DataInfo(item[3], image[3], description[3], cost[3]));

        final MenuAdapter adapter = new MenuAdapter(this);

        ListView listView = (ListView)findViewById(R.id.list);
        listView.setAdapter(adapter);

        for (int i = 0; i < item.length; i++) {
            adapter.addData(String.valueOf(i), item[i], image[i], description[i], cost[i]);
        }

        buttonorder = (Button) findViewById(R.id.suborder);
        buttonorder.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            String[] a = adapter.getQuantity();
                Toast.makeText(getApplicationContext(), "Noodle: " + a[0] + "\nRice: " + a[1] +
                        "\nSteam fish: " + a[2] + "\nIced tea: " + a[3], Toast.LENGTH_LONG).show();

                int sum = 0;
                if (!adapter.getQuantity()[0].equals(""))
                {
                    //check whether checkbox is selected if yes, price +
                    sum += Integer.parseInt(adapter.getQuantity()[0])*Integer.parseInt(cost[0]);
                }
                if (!adapter.getQuantity()[1].equals(""))
                {
                    sum += Integer.parseInt(adapter.getQuantity()[1])*Integer.parseInt(cost[1]);
                }
                if (!adapter.getQuantity()[2].equals(""))
                {
                    sum += Integer.parseInt(adapter.getQuantity()[2])*Integer.parseInt(cost[2]);
                }
                if (!adapter.getQuantity()[3].equals(""))
                {
                    sum += Integer.parseInt(adapter.getQuantity()[3])*Integer.parseInt(cost[3]);
                }

                Intent intent = new Intent(getApplicationContext(), activityresult2.class);
                Bundle bundle = new Bundle();
                bundle.putString("Noodle quantity", adapter.getQuantity()[0]);
                bundle.putString("Rice quantity", adapter.getQuantity()[1]);
                bundle.putString("Fish quantity", adapter.getQuantity()[2]);
                bundle.putString("Iced tea", adapter.getQuantity()[3]);
                bundle.putInt("sum", sum);
                bundle.putBoolean("ANI", adapter.getItem(0).isAddInisCheck());//add noodle ingredients
                bundle.putBoolean("ARI", adapter.getItem(1).isAddInisCheck()); // add rice ingredients
                bundle.putBoolean("AFI", adapter.getItem(2).isAddInisCheck());// add fish ingredients
                bundle.putBoolean("AIT", adapter.getItem(3).isAddInisCheck()); // add ice tea ingredients
                intent.putExtras(bundle);
                startActivityForResult(intent, REQUEST_CODE);
            }
        });
    }

}



